import SwiftUI

@main
struct Calculator: App {
    var body: some Scene {
        WindowGroup {
            CalculatorGrid()
        }
    }
}
