import SwiftUI

struct CalculatorGrid: View {
    
    @State var result = ""
    
    @State var total = ""
    
    @State var refresh: Bool = false
    
    @State var currentModifier = ""
    
    @State var isDarkMode: Bool = false
    
    @State var themeColor = Color.white
    
    @State var themeAccent = Color.accentColor
    
    @State var themeForeground = Color.white
    
    @State var themeForegroundAccent = Color.accentColor
    
    @State var themeOffColor = Color.gray
    
    @State var fontScale: Double = 1.5
    
    func toggleTheme(isDarkMode: Bool) {
        if isDarkMode == true {
            themeColor = Color.black.opacity(0.9)
            themeAccent = Color.gray
            themeForeground = Color.white
            themeForegroundAccent = Color.white
            themeOffColor = Color.accentColor
        } else {
            themeColor = Color.white
            themeAccent = Color.accentColor
            themeForeground = Color.white
            themeForegroundAccent = Color.accentColor
            themeOffColor = Color.gray
        }
    }
    
    func calculate(number: String, calc: String) {
        if refresh == true {
            refresh = false
            total = result
            result = "0"
        }
        if result.count <= 9 {
            fontScale = 1.5
        }
        if number != "00" {
            if result.count > 9 {
            } else {
                if result == "0" {
                    result = number
                } else {
                    result = result + number
                }
            }
        } else if calc == "=" {
            if currentModifier == "+" {
                let totalInt = Double(total) ?? 0
                let resultInt = Double(result) ?? 0
                result = String((totalInt + resultInt).rounded())
                total = result
                if result.count > 9 {
                    fontScale = 1
                }
            } else if currentModifier == "-" {
                let totalInt = Double(total) ?? 0
                let resultInt = Double(result) ?? 0
                result = String((totalInt - resultInt).rounded())
                total = result
                if result.count > 9 {
                    fontScale = 1
                }
            } else if currentModifier == "*" {
                let totalInt = Double(total) ?? 0
                let resultInt = Double(result) ?? 0
                result = String((totalInt * resultInt).rounded())
                total = result
                if result.count > 9 {
                    fontScale = 1
                }
            } else if currentModifier == "/" {
                let totalInt = Double(total) ?? 0
                let resultInt = Double(result) ?? 0
                result = String((totalInt / resultInt).rounded())
                total = result
                if result.count > 9 {
                    fontScale = 1
                }
            }
        } else if calc != "" {
            if calc == "cancel" {
                result = "0"
                total = "0"
                fontScale = 1.5
            } else {
                currentModifier = calc
                refresh = true
            }
        }
    }
    
    var body: some View {
        
        VStack {
            HStack {
                VStack(alignment: .center) {
                    Text("Dark Mode")
                        .foregroundColor(themeForegroundAccent)
                    Toggle("", isOn: $isDarkMode)
                        .padding(.trailing, 15.0)
                        .onChange(of: isDarkMode) { value in
                            if value == true {
                                toggleTheme(isDarkMode: true)
                            } else {
                                toggleTheme(isDarkMode: false)
                            }
                        }
                        .scaleEffect(0.75)
                        .frame(width: 70)
                }
                .frame(width: 100, height: 50)
                Spacer()
            }
            Spacer()
            
            Text(result)
                .foregroundColor(themeForegroundAccent)
                .font(.largeTitle)
                .multilineTextAlignment(.trailing)
                .scaleEffect(fontScale)
                .frame(maxWidth: 300, alignment: .trailing)

            VStack {
                HStack {
                    Button(action: {calculate(number: "00", calc: "cancel")}) {
                        Text("C")
                            .foregroundColor(themeForeground)
                            .frame(width: 225, height: 70)
                            .scaleEffect(1.5)
                            .background(themeOffColor)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: "00", calc: "/")}) {
                        Text("/")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeOffColor)
                            .cornerRadius(100)
                    }
                }
                HStack {
                    Button(action: {calculate(number: "7", calc: "")}) {
                        Text("7")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeAccent)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: "8", calc: "")}) {
                        Text("8")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeAccent)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: "9", calc: "")}) {
                        Text("9")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeAccent)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: "00", calc: "*")}) {
                        Text("*")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeOffColor)
                            .cornerRadius(100)
                    }
                }
                HStack {
                    Button(action: {calculate(number: "4", calc: "")}) {
                        Text("4")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeAccent)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: "5", calc: "")}) {
                        Text("5")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeAccent)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: "6", calc: "")}) {
                        Text("6")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeAccent)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: "00", calc: "-")}) {
                        Text("-")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeOffColor)
                            .cornerRadius(100)
                    }
                }
                HStack {
                    Button(action: {calculate(number: "1", calc: "")}) {
                        Text("1")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeAccent)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: "2", calc: "")}) {
                        Text("2")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeAccent)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: "3", calc: "")}) {
                        Text("3")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeAccent)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: "00", calc: "+")}) {
                        Text("+")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeOffColor)
                            .cornerRadius(100)
                    }
                }
                HStack {
                    Button(action: {calculate(number: "0", calc: "")}) {
                        Text("0")
                            .foregroundColor(themeForeground)
                            .frame(width: 150, height: 70)
                            .scaleEffect(1.5)
                            .background(themeAccent)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: ".", calc: "")}) {
                        Text(".")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(2)
                            .background(themeAccent)
                            .cornerRadius(100)
                    }
                    Button(action: {calculate(number: "00", calc: "=")}) {
                        Text("=")
                            .foregroundColor(themeForeground)
                            .frame(width: 70, height: 70)
                            .scaleEffect(1.5)
                            .background(themeOffColor)
                            .cornerRadius(100)
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background {
            themeColor
            .ignoresSafeArea()
        }
    }
}

